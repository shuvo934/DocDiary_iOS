# Dashboard step 1 source mapping

Reference: supplied Android DocDiary 1.3.9.5 source. Source-file SHA-256 values
are recorded in `dashboard_native_reference.json`. The Play Store app and Android
source have not been modified.

| Flutter component | Native reference | Scope |
| --- | --- | --- |
| Header / white surface | activity_doc_dashboard.xml; ShapeAppearanceOverlay.MaterialCardView.Cut | Clouds header, 12sdp padding, 22sdp logo, 14sdp Poppins Bold title, 30dp top corners |
| Identity | activity_doc_dashboard.xml; updateInterface/updateAdminInterface | Poppins greeting/name/center, parentheses, 42sdp role-specific circular default photo |
| Center-name color | @color/colorLightBlue from HappyTimer/src/main/res/values/colors.xml | #2196F3; app-local colors.xml does not redeclare this inherited resource |
| Doctor actions | DocDashboard.updateInterface | doc_manager_flag takes precedence; doc_deptd_head_flag enables Unit Appointment otherwise |
| Summary tabs | three_tab_layout; NavigationTabTextAppeareance; tab_color_selector | Four fixed tabs, Patua One, primary-to-green-sea selected capsule, white indicator |
| Date labels | DocDashboard tab selection listener | dd MMMM, yy; Saturday–Friday and calendar-month API ranges retained |
| Schedule/admin cards | activity_doc_dashboard.xml; doc_dashboard_extra_layout.xml | Native padding, labels, Baloo numerals, design_new/border_design_1/design_new_2 colors |
| Appointment cards | activity_doc_dashboard.xml | Original dotted PNG, orange/teal/gray, 77sdp minimum height |
| Doctor bottom menu | bottom_menu.xml | Profile, Appointment, Block Time, Patient; no Home entry; unlabeled white icons |
| Admin bottom menu | bottom_menu_admin.xml; updateAdminInterface | Payment/Appointment visibility for HR/Accounts flags; Patient and Reports/Management |
| Picture GET requests | getDocSchedule/getAdminDashboardData | getDocPic?doc_id and getAdminPic?p_usr_id; base64 image fields; native fallback assets |
| Next Meeting text | updateInterface/updateLayout | Title, timestamp and patient text only; timer/progress not ported in this step |

PNG files are copied byte-for-byte. The logout/profile/appointment/block/payment/
camera vector paths are translated directly into Flutter Canvas Path operations.
No icon package or image-generating service substitutes their artwork.

SDP measurements use the same 30dp smallest-width buckets and 300dp baseline as
the earlier approved screens. Actual iOS font rasterization, shadows, tab wrapping
and system insets require device/screenshot review; source inspection cannot
establish pixel-level equality.

Native uses the original Baloo family, not Baloo 2. Baloo 1.443 is bundled from
Google's font endpoint with the font author's OFL. Archivo is the Google Fonts
variable face at weight 700/width 100, alongside existing approved fonts. Licences
and hashes are bundled in assets/fonts. The inherited center color was resolved
from the upstream HappyTimer resource:
https://github.com/happysingh23828/HappyTimer/blob/master/HappyTimer/src/main/res/values/colors.xml

## Behavior boundaries

- Existing DashboardRepository.load implementation is unchanged. It checks forced
  logout before summaries, uses native field/parameter names and preserves raw
  monetary strings. Formatting adds `৳` and grouping without rounding decimals.
- Picture loading is separate and read-only. Empty/malformed/missing photo data
  falls back to the native role-specific PNG. A picture failure does not block
  the dashboard summary.
- Period changes and refresh revalidate with recordLogin:false. AuthController,
  profile checks, session vault, login/splash/selection and app routing are unchanged.
- Switch availability continues to use the existing AuthController.canSwitch.
  Android shows its icon whenever any center list exists, including a single
  non-switchable account. That single-account icon behavior is not changed here.
- New destination screens are pending and show an availability notice in this
  development build. Camera upload/crop and admin chart endpoints are not invoked.
- Native next-time rendering has two spacing/leading-zero branches based on
  last_sc. This checkpoint formats next_sc as `At hh:mm AM/PM`, adding the actual
  calendar date for a different day. Full last_sc/progress/countdown parity is pending.
- Next-meeting data is retained while a period request loads; summary counts are
  hidden while loading or failed. No zero-filled data is fabricated.

## Verification evidence

Offline source/import/asset checks, an independent Dart syntax grammar parser,
font/asset checks and installer preservation/rollback fixtures run locally.
These do **not** replace flutter analyze, flutter test or an iOS build. Flutter,
Dart and Xcode are unavailable here. Mac runtime/visual acceptance is pending.
