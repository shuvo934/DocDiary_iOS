# Migration status — 15 October 2026

Baseline: supplied `DocDiary.zip`, Android version 1.3.9.5 (27). Its SHA-256 and the
reference source checksums are recorded in `native_baseline.json`.

Status vocabulary:

- **Drafted**: Dart implementation exists; Flutter compilation/device acceptance still pending.
- **Partial**: only the listed subset exists.
- **Pending**: implementation has not started.
- **Accepted**: reserved for a verified build plus agreed device/behaviour checks. Nothing is accepted yet.

| Native area | Current implementation | Status |
| --- | --- | --- |
| Startup routing | Keychain restoration, loading and retry states | Drafted |
| Login | Server discovery, native response variants, validation | Drafted |
| Centre/account selection | Modal-style selections, cancellation, role-specific choice | Drafted |
| Session/access | Native flag resets, expiry/access checks, login logs, secure persistence, logout/switch | Drafted |
| Dashboard | Identity, date periods, doctor/admin summaries, next-meeting text | Partial |
| Dashboard charts/pictures/countdown/navigation | Not implemented | Pending |
| Profile edit/camera/crop | Not implemented | Pending |
| Appointment schedules/unit/all/admin changes | Not implemented | Pending |
| Patient search/history/health progress | Not implemented | Pending |
| Old prescription workflows | Not implemented | Pending |
| Dynamic prescription/vitals/history/PDF/print/share | Not implemented | Pending |
| Payments/service modifications | Not implemented | Pending |
| Reports/PDF viewing | Not implemented | Pending |
| HR, Accounts, approvals and analytics | Not implemented | Pending |
| Camera and PDF iOS feasibility trials | Not performed | Pending |
| TestFlight/App Store preparation | Not started | Pending |

## Next checkpoint

Run setup, analyzer and tests on Mac. Resolve any failures. Build on iOS simulator,
then exercise login with the same permitted test accounts on Android and iPhone.
Capture screen/behaviour differences before calling this milestone accepted.
Run a focused camera/crop and multipage prescription PDF iOS trial before bulk screen migration.

## Deliberate migration decisions to validate

- Keychain replaces Android SharedPreferences for credentials/session data.
- The same backend routes/parameters/custom headers are retained; inputs are correctly URI-encoded.
- Unsupported roles and malformed account identifiers are rejected rather than treated as admin.
- A failure at the last discovery server does not discard earlier valid centres.
- Write POSTs are not automatically retried, so a connection failure requires an explicit user retry.
- iOS update/review/system dialogs will follow iOS facilities; Google Play APIs are not ported.
- Login fonts are fetched during Mac setup because the native ZIP contains downloadable-font XML,
  not the font binaries. Font acquisition and visual parity remain pending until that run.
- Native Current Week explicitly starts **Saturday** and ends **Friday**.
- Native doctor “COMPLETED” is based on elapsed schedule time, not clinical completion; that meaning is preserved.
- The iOS deployment target and bundle ID are provisional; review before release.

