import 'package:flutter/material.dart';

import 'app.dart';
import 'config/server_directory.dart';
import 'core/native_json.dart';
import 'core/transport.dart';
import 'features/auth/auth_controller.dart';
import 'features/auth/auth_models.dart';
import 'features/auth/auth_repository.dart';
import 'features/auth/profile_repository.dart';
import 'features/auth/session_vault.dart';
import 'features/dashboard/dashboard_repository.dart';

/// Fully offline fixtures. main.dart remains the live API/Keychain entry point.
/// --dart-define=DASHBOARD_PREVIEW_ROLE=admin (or doctor, unit, hr, accounts).
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const role = String.fromEnvironment(
    'DASHBOARD_PREVIEW_ROLE',
    defaultValue: 'doctor',
  );
  final clock = DateTime(2026, 10, 17, 10, 30);
  final transport = _DashboardPreviewTransport(role);
  const doctor = AccountOption(
    role: AccountRole.doctor,
    doctorCode: 'D-10',
    doctorName: 'Example Therapist',
    department: 'Physiotherapy',
  );
  const admin = AccountOption(
    role: AccountRole.admin,
    adminId: '70',
    adminFirstName: 'Example',
    adminLastName: 'Administrator',
    adminUserName: 'example.admin',
  );
  final center = CenterOption(
    name: 'Example Rehabilitation Centre',
    baseUri: Uri.parse('https://dashboard.preview.invalid/api/'),
    accounts: const [doctor, admin],
    requiresAccountChoice: true,
  );
  final session = AuthSession(
    credentials: const Credentials('00000000000', 'preview-only'),
    center: center,
    account: transport.doctor ? doctor : admin,
    centers: [center],
    remember: false,
  );
  final auth = AuthController(
    repository: AuthRepository(transport, ServerDirectory(transport)),
    profiles: ProfileRepository(
      transport,
      now: () => clock,
      describeClient: () async => const ClientDescriptor(),
    ),
    vault: _DashboardPreviewVault(session),
  );
  await auth.initialize();
  runApp(
    DocDiaryApp(
      auth: auth,
      dashboard: DashboardRepository(transport, now: () => clock),
      initializeOnStart: false,
      onDispose: transport.close,
    ),
  );
}

class _DashboardPreviewTransport implements Transport {
  _DashboardPreviewTransport(this.role);
  final String role;
  bool get doctor => role == 'doctor' || role == 'unit';

  @override
  Future<String> getText(Uri uri) async =>
      'https://dashboard.preview.invalid/api/';

  @override
  Future<JsonMap> get(Uri uri) async {
    final route = uri.path.split('/').last;
    switch (route) {
      case 'getDocData':
        return {
          'items': [
            {
              'user_avail': '1',
              'doc_id': '10',
              'doc_code': 'D-10',
              'doc_name': 'Example Therapist',
              'doc_center_name': 'Example Rehabilitation Centre',
              'fl_flag': '0',
              'access_flag': '1',
              'doc_app_first_login_flag': '1',
              'exp_date': '17-JAN-27',
              'doc_manager_flag': role == 'doctor' ? '1' : '0',
              'doc_deptd_head_flag': role == 'unit' ? '1' : '0',
            },
          ],
        };
      case 'getAdminData':
        return {
          'items': [
            {
              'usr_id': '70',
              'usr_name': 'example.admin',
              'usr_fname': 'Example',
              'usr_lname': 'Administrator',
              'admin_center_name': 'Example Rehabilitation Centre',
              'usr_mob_app_access': '1',
              'usr_mob_forced_log_out_flag': '0',
              'usr_app_first_login_flag': '1',
              'exp_date': '17-JAN-27',
              'all_access_flag':
                  role == 'hr'
                      ? '2'
                      : role == 'accounts'
                      ? '3'
                      : '1',
              'hr_acc_active_flag': '1',
              'hr_payment_active': '0',
              'hr_appointment_active': '1',
              'acc_payment_active': '1',
              'acc_appointment_active': '0',
            },
          ],
        };
      case 'getDocFLFlag':
      case 'getAdminFLFlag':
        return {
          'items': [
            {'fl_flag': '0'},
          ],
        };
      case 'getMeetingCount':
        return {
          'count': 8,
          'items': [
            for (final time in [
              '09:00 AM',
              '09:30 AM',
              '10:00 AM',
              '10:30 AM',
              '11:00 AM',
              '11:30 AM',
              '12:00 PM',
              '12:30 PM',
            ])
              {'appointment_date': '17-OCT-26', 'schedule_time': time},
          ],
        };
      case 'getScheduleCount':
        return {
          'items': [
            {'schedule': '12', 'block_schedule': '2'},
          ],
        };
      case 'getMeetingSchedule':
        return {
          'items': [
            {
              'last_sc': '17-10-2026 10:30:00',
              'next_sc': '17-10-2026 11:00:00',
              'pat_name': 'Example Patient',
            },
          ],
        };
      case 'getAdminAppPayCountNew':
        return {
          'total_app_count': '248',
          'cancel_app_count': '12',
          'total_pay_rcv': '123456.50',
          'total_pay_rtn': '1250.25',
        };
      case 'getDocPic':
      case 'getAdminPic':
        return {'count': 0, 'items': <Object?>[]};
      default:
        throw StateError(
          'This fixture has no data for $route. Use main.dart for live login.',
        );
    }
  }

  @override
  Future<JsonMap> post(
    Uri uri, {
    Map<String, String> headers = const {},
  }) async => {'string_out': 'Successfully Created'};

  @override
  void close() {}
}

class _DashboardPreviewVault implements SessionVault {
  _DashboardPreviewVault(AuthSession session)
    : state = VaultState(session: session);
  VaultState state;

  @override
  Future<VaultState> load() async => state;

  @override
  Future<void> saveSession(AuthSession session) async {
    state = VaultState(session: session);
  }

  @override
  Future<void> clearSession() async {
    state = const VaultState();
  }
}
