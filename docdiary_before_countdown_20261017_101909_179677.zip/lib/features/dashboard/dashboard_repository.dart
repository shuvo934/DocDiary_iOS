import 'dart:convert';
import 'dart:typed_data';

import '../../core/failure.dart';
import '../../core/native_dates.dart';
import '../../core/native_json.dart';
import '../../core/transport.dart';
import '../auth/auth_models.dart';
import '../auth/profile_repository.dart';

class DashboardSummary {
  const DashboardSummary({
    required this.values,
    this.nextTime = '',
    this.nextPatient = '',
  });
  final Map<String, String> values;
  final String nextTime;
  final String nextPatient;
}

class DashboardRepository {
  DashboardRepository(this.transport, {DateTime Function()? now})
    : now = now ?? DateTime.now;
  final Transport transport;
  final DateTime Function() now;

  /// The picture is an optional, read-only request, separate from summaries.
  Future<Uint8List?> loadPicture(
    AuthSession session,
    AccountProfile profile,
  ) async {
    final response = await transport.get(
      apiEndpoint(
        session.center.baseUri,
        profile.isDoctor
            ? 'doc_dashboard/getDocPic'
            : 'doc_dashboard/getAdminPic',
        profile.isDoctor
            ? {'doc_id': profile.doctorId}
            : {'p_usr_id': session.account.adminId},
      ),
    );
    final items = nativeItems(response);
    if (items.isEmpty) {
      return null;
    }
    final encoded = nativeText(
      items.first[profile.isDoctor ? 'doc_profile_pic' : 'usr_profile_pic'],
    );
    if (encoded.isEmpty) {
      return null;
    }
    try {
      return base64Decode(encoded.replaceAll(RegExp(r'\s+'), ''));
    } on FormatException {
      return null;
    }
  }

  Future<DashboardSummary> load(
    AuthSession session,
    AccountProfile profile,
    SummaryPeriod period,
  ) async {
    final clock = now();
    final range = SummaryRange.forPeriod(period, clock);
    final doctor = profile.isDoctor;
    final flag = await transport.get(
      apiEndpoint(
        session.center.baseUri,
        doctor ? 'doc_dashboard/getDocFLFlag' : 'doc_dashboard/getAdminFLFlag',
        doctor
            ? {'p_doc_id': profile.doctorId}
            : {'p_usr_id': session.account.adminId},
      ),
    );
    final flags = nativeItems(flag);
    if (flags.isEmpty) {
      throw const AppFailure(
        'Account access could not be verified. Please try again.',
      );
    }
    if (nativeText(flags.first['fl_flag']) == '1') {
      throw const AppFailure(
        'You are forced to log out from the app for server maintenance. Please Login again to continue the app.',
        kind: FailureKind.denied,
      );
    }
    if (!doctor) {
      final response = await transport.get(
        apiEndpoint(
          session.center.baseUri,
          'doc_dashboard/getAdminAppPayCountNew',
          {
            'begin_date': oracleDate(range.first),
            'end_date': oracleDate(range.last),
            'user_id': profile.adminFilter,
          },
        ),
      );
      return DashboardSummary(
        values: {
          'TOTAL APPOINTMENT': nativeText(response['total_app_count'], '0'),
          'CANCELED APPOINTMENT': nativeText(response['cancel_app_count'], '0'),
          'PAYMENT RECEIVED': nativeText(response['total_pay_rcv'], '0'),
          'PAYMENT RETURNED': nativeText(response['total_pay_rtn'], '0'),
        },
      );
    }
    final query = {
      'doc_id': profile.doctorId,
      'first_date': oracleDate(range.first),
      'end_date': oracleDate(range.last),
    };
    final responses = await Future.wait([
      transport.get(
        apiEndpoint(
          session.center.baseUri,
          'doc_dashboard/getMeetingCount',
          query,
        ),
      ),
      transport.get(
        apiEndpoint(
          session.center.baseUri,
          'doc_dashboard/getScheduleCount',
          query,
        ),
      ),
      transport.get(
        apiEndpoint(
          session.center.baseUri,
          'doc_dashboard/getMeetingSchedule',
          {'doc_id': profile.doctorId, 'time_now': nativeClockRequest(clock)},
        ),
      ),
    ]);
    final appointments = nativeItems(responses[0]);
    var completed = 0;
    var remaining = 0;
    for (final row in appointments) {
      final time = nativeText(row['schedule_time']);
      if (time.isEmpty) continue;
      final day = nativeText(row['appointment_date'], oracleDate(clock));
      final appointment = parseAppointmentTime(day, time);
      if (appointment.isAfter(clock)) {
        remaining++;
      } else {
        completed++;
      }
    }
    final schedules = nativeItems(responses[1]);
    final schedule = schedules.isEmpty ? <String, Object?>{} : schedules.first;
    final next = nativeItems(responses[2]);
    return DashboardSummary(
      values: {
        'TOTAL SCHEDULE': nativeText(schedule['schedule'], '0'),
        'BLOCKED SCHEDULE': nativeText(schedule['block_schedule'], '0'),
        // Native "COMPLETED" means scheduled time has elapsed, not a clinical status.
        'TOTAL': nativeText(
          responses[0]['count'],
          appointments.length.toString(),
        ),
        'COMPLETED': completed.toString(),
        'REMAINING': remaining.toString(),
      },
      nextTime: next.isEmpty ? '' : nativeText(next.first['next_sc']),
      nextPatient: next.isEmpty ? '' : nativeText(next.first['pat_name']),
    );
  }
}
