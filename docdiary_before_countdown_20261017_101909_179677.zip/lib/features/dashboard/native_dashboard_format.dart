import '../../core/native_dates.dart';

const _monthNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

String _two(int value) => value.toString().padLeft(2, '0');

String _fullDate(DateTime day) =>
    '${_two(day.day)} ${_monthNames[day.month - 1]}, ${_two(day.year % 100)}';

/// DocDashboard uses a full English date, including both ends of a range.
String nativeDashboardDate(SummaryPeriod period, DateTime now) {
  final range = SummaryRange.forPeriod(period, now);
  return period == SummaryPeriod.today
      ? _fullDate(range.first)
      : '${_fullDate(range.first)}  --  ${_fullDate(range.last)}';
}

/// Match the native currency prefix/grouping without rounding API decimals.
/// Android DecimalFormat groups these amounts in threes despite the pattern's
/// intermediate commas. No conversion through double is used here.
String nativeDashboardMoney(String value) {
  final clean = value.trim();
  final match = RegExp(r'^([+-]?)(\d+)(\.\d+)?$').firstMatch(clean);
  if (match == null) {
    return '৳ $clean';
  }
  final digits = match[2]!;
  final grouped = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) {
      grouped.write(',');
    }
    grouped.write(digits[i]);
  }
  return '৳ ${match[1]}$grouped${match[3] ?? ''}';
}

/// Display the native next_sc timestamp. Live countdown/progress is a separate
/// dashboard checkpoint; this function only formats the meeting information.
String nativeDashboardMeeting(String value, DateTime now) {
  final match = RegExp(
    r'^(\d{2})-(\d{2})-(\d{4}) (\d{2}):(\d{2}):(\d{2})$',
  ).firstMatch(value.trim());
  if (match == null) {
    return value;
  }
  final day = int.parse(match[1]!);
  final month = int.parse(match[2]!);
  final year = int.parse(match[3]!);
  final hour = int.parse(match[4]!);
  final minute = int.parse(match[5]!);
  final second = int.parse(match[6]!);
  final date = DateTime(year, month, day, hour, minute, second);
  if (date.year != year ||
      date.month != month ||
      date.day != day ||
      hour > 23 ||
      minute > 59 ||
      second > 59) {
    return value;
  }
  final clock =
      '${_two(hour % 12 == 0 ? 12 : hour % 12)}:${_two(minute)} '
      '${hour < 12 ? 'AM' : 'PM'}';
  if (dateOnly(date) == dateOnly(now)) {
    return 'At $clock';
  }
  return 'At $clock\nIn ${_two(day)} ${_monthNames[month - 1].substring(0, 3)}, ${_two(year % 100)}';
}
