import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/failure.dart';
import '../../core/native_dates.dart';
import '../auth/auth_controller.dart';
import '../auth/auth_models.dart';
import '../auth/profile_repository.dart';
import 'dashboard_repository.dart';
import 'native_dashboard_layout.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.auth,
    required this.repository,
  });
  final AuthController auth;
  final DashboardRepository repository;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with WidgetsBindingObserver {
  late AccountProfile _profile;
  DashboardSummary? _summary;
  Uint8List? _picture;
  SummaryPeriod _period = SummaryPeriod.today;
  String? _error;
  bool _loading = false;
  bool _noticeOpen = false;
  int _request = 0;
  int _pictureRequest = 0;

  @override
  void initState() {
    super.initState();
    _profile = widget.auth.profile!;
    WidgetsBinding.instance.addObserver(this);
    // AuthController already checked this account before opening the dashboard.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(_load(revalidate: false, refreshPicture: true));
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_loading) {
      unawaited(_load(refreshPicture: true));
    }
  }

  Future<void> _load({
    bool revalidate = true,
    bool refreshPicture = false,
  }) async {
    if (!mounted || _loading) {
      return;
    }
    final session = widget.auth.session;
    if (session == null) {
      return;
    }
    final request = ++_request;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final profile =
          revalidate
              ? await widget.auth.profiles.open(session, recordLogin: false)
              : _profile;
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      final result = await widget.repository.load(session, profile, _period);
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      setState(() {
        _profile = profile;
        _summary = result;
      });
      if (refreshPicture) {
        unawaited(_loadPicture(session, profile));
      }
    } catch (failure) {
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      if (failure is AppFailure && failure.kind == FailureKind.denied) {
        await widget.auth.logout(message: failure.message);
        return;
      }
      setState(
        () =>
            _error =
                failure is AppFailure
                    ? failure.message
                    : 'Dashboard data could not be loaded. Please try again.',
      );
    } finally {
      if (mounted && request == _request) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _loadPicture(AuthSession session, AccountProfile profile) async {
    final request = ++_pictureRequest;
    Uint8List? picture;
    try {
      picture = await widget.repository.loadPicture(session, profile);
    } catch (_) {
      // A failed optional picture request uses the native role-specific image.
    }
    if (mounted &&
        request == _pictureRequest &&
        widget.auth.session == session) {
      setState(() => _picture = picture);
    }
  }

  Future<void> _refresh() => _load(refreshPicture: true);

  Future<void> _selectPeriod(SummaryPeriod period) async {
    if (_loading || period == _period) {
      return;
    }
    setState(() => _period = period);
    await _load();
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Log Out!'),
            content: const Text('Do you want to log out?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Yes'),
              ),
            ],
          ),
    );
    if (confirmed == true && mounted) {
      await widget.auth.logout();
    }
  }

  Future<void> _openDestination(DashboardDestination destination) async {
    if (_noticeOpen) {
      return;
    }
    _noticeOpen = true;
    final label = switch (destination) {
      DashboardDestination.profile => 'Profile',
      DashboardDestination.appointment => 'Appointment',
      DashboardDestination.leave => 'Block Time',
      DashboardDestination.patients => 'Patient',
      DashboardDestination.payment => 'Payment',
      DashboardDestination.management =>
        nativeDashboardMenu(
          _profile,
        ).firstWhere((item) => item.destination == destination).label,
      DashboardDestination.unitAppointment => 'Unit Appointment',
      DashboardDestination.allAppointment => 'All Appointment',
      DashboardDestination.reports => 'Report Manager',
      DashboardDestination.changePhoto => 'Profile picture',
    };
    try {
      await showDialog<void>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: Text(label),
              content: const Text(
                'This screen is not available in this development build.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close'),
                ),
              ],
            ),
      );
    } finally {
      _noticeOpen = false;
    }
  }

  @override
  void dispose() {
    ++_request;
    ++_pictureRequest;
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => NativeDashboardLayout(
    profile: _profile,
    summary: _summary,
    picture: _picture,
    period: _period,
    now: widget.repository.now(),
    loading: _loading,
    error: _error,
    showSwitch: widget.auth.canSwitch,
    onSwitch: widget.auth.beginSwitch,
    onLogout: _logout,
    onPeriod: _selectPeriod,
    onRefresh: _refresh,
    onDestination: _openDestination,
  );
}
