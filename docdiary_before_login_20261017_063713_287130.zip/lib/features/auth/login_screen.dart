import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_theme.dart';
import 'auth_controller.dart';
import 'auth_models.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.controller});
  final AuthController controller;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _mobile = TextEditingController();
  final _password = TextEditingController();
  bool _remember = false;
  bool _hidePassword = true;

  @override
  void initState() {
    super.initState();
    final saved = widget.controller.formCredentials;
    if (saved != null) {
      _mobile.text = saved.mobile;
      _password.text = saved.password;
      _remember = widget.controller.formRemember;
    }
  }

  @override
  void dispose() {
    _mobile.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    await widget.controller.login(
      _mobile.text,
      _password.text,
      remember: _remember,
    );
  }

  Future<void> _contact() async {
    final approved = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            content: const Text(
              'Do you want to send an email to info@techterrain-it.com ?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Yes'),
              ),
            ],
          ),
    );
    if (approved != true || !mounted) return;
    const body =
        'Please fill out the field to create your user id.\n\n'
        'Center/Hospital Name: \nCenter/Hospital Address: \nUser Name: \n'
        'User Mobile No: \nUser Designation: \nUser Mail: \nUser Code(If any): ';
    final uri = Uri(
      scheme: 'mailto',
      path: 'info@techterrain-it.com',
      query:
          'subject=${Uri.encodeComponent('New Account Creation Request From DocDiary')}'
          '&body=${Uri.encodeComponent(body)}',
    );
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('There is no email app found.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('There is no email app found.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = widget.controller;
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final headerHeight =
                (constraints.maxHeight * .35).clamp(170.0, 290.0).toDouble();
            return SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: Column(
                  children: [
                    SizedBox(
                      height: headerHeight,
                      width: double.infinity,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.asset(
                            'assets/images/docdiary_login_fron_view_new.png',
                            fit: BoxFit.fill,
                          ),
                          Center(
                            child: Image.asset(
                              'assets/images/doc_diary_logo_shadow.png',
                              width: 210,
                              height: 160,
                              fit: BoxFit.contain,
                              semanticLabel: 'DocDiary',
                            ),
                          ),
                        ],
                      ),
                    ),
                    Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 540),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(24, 16, 24, 20),
                          child: AutofillGroup(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                const Text(
                                  'WELCOME!',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: DocColors.greenSea,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  'Login to continue',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontFamily: 'PatuaOne',
                                    fontSize: 17,
                                  ),
                                ),
                                const SizedBox(height: 22),
                                if (auth.error != null) ...[
                                  ErrorNotice(auth.error!),
                                  const SizedBox(height: 16),
                                ],
                                TextField(
                                  key: const Key('mobile_field'),
                                  controller: _mobile,
                                  enabled: !auth.busy,
                                  keyboardType: TextInputType.phone,
                                  textInputAction: TextInputAction.next,
                                  autofillHints: const [AutofillHints.username],
                                  style: const TextStyle(
                                    fontFamily: 'Ubuntu',
                                    fontWeight: FontWeight.w500,
                                  ),
                                  autocorrect: false,
                                  decoration: const InputDecoration(
                                    hintText: 'Mobile No',
                                    labelText: 'Mobile No',
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.never,
                                  ),
                                ),
                                const SizedBox(height: 18),
                                TextField(
                                  key: const Key('password_field'),
                                  controller: _password,
                                  enabled: !auth.busy,
                                  obscureText: _hidePassword,
                                  autocorrect: false,
                                  enableSuggestions: false,
                                  textInputAction: TextInputAction.done,
                                  autofillHints: const [AutofillHints.password],
                                  style: const TextStyle(
                                    fontFamily: 'Ubuntu',
                                    fontWeight: FontWeight.w500,
                                  ),
                                  onSubmitted: (_) async {
                                    if (!auth.busy) await _submit();
                                  },
                                  decoration: InputDecoration(
                                    hintText: 'Password',
                                    labelText: 'Password',
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.never,
                                    suffixIcon: IconButton(
                                      tooltip:
                                          _hidePassword
                                              ? 'Show password'
                                              : 'Hide password',
                                      onPressed:
                                          () => setState(
                                            () =>
                                                _hidePassword = !_hidePassword,
                                          ),
                                      icon: Icon(
                                        _hidePassword
                                            ? Icons.visibility_off_outlined
                                            : Icons.visibility_outlined,
                                        color: DocColors.muted,
                                      ),
                                    ),
                                  ),
                                ),
                                CheckboxListTile(
                                  key: const Key('remember_me'),
                                  value: _remember,
                                  onChanged:
                                      auth.busy
                                          ? null
                                          : (value) => setState(
                                            () => _remember = value ?? false,
                                          ),
                                  controlAffinity:
                                      ListTileControlAffinity.leading,
                                  contentPadding: EdgeInsets.zero,
                                  activeColor: DocColors.greenSea,
                                  title: const Text(
                                    'Remember Me',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: DocColors.muted,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                ElevatedButton(
                                  key: const Key('login_button'),
                                  onPressed: auth.busy ? null : _submit,
                                  child:
                                      auth.busy
                                          ? const SizedBox(
                                            width: 24,
                                            height: 24,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                              color: Colors.white,
                                            ),
                                          )
                                          : const Text('LOGIN'),
                                ),
                                if (auth.busy) ...[
                                  const SizedBox(height: 12),
                                  Text(
                                    auth.stage == AuthStage.discovering
                                        ? 'Checking your centres…'
                                        : 'Completing sign-in…',
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: DocColors.muted,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 24),
                                const Text(
                                  "Don't have an account?",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 13),
                                ),
                                TextButton(
                                  onPressed: auth.busy ? null : _contact,
                                  child: const Text(
                                    'Contact Here',
                                    style: TextStyle(
                                      color: DocColors.primary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class SelectionScreen extends StatelessWidget {
  const SelectionScreen({super.key, required this.controller});
  final AuthController controller;

  @override
  Widget build(BuildContext context) {
    final center = controller.selectedCenter;
    final choosingAccount = controller.stage == AuthStage.chooseAccount;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black38,
        body: SafeArea(
          child: Center(
            child: Dialog(
              insetPadding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: 560,
                  maxHeight: MediaQuery.sizeOf(context).height * .82,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      color: DocColors.primary,
                      padding: const EdgeInsets.only(left: 16),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.local_hospital_outlined,
                            color: Colors.white,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              choosingAccount && center != null
                                  ? center.name
                                  : 'SELECT CENTER',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Cancel selection',
                            icon: const Icon(Icons.close, color: Colors.white),
                            onPressed: controller.cancelSelection,
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(12),
                        children: [
                          Text(
                            choosingAccount
                                ? 'We have found Multiple USER ID for your login credentials. Please Select One to proceed.'
                                : 'We have found Multiple Center for your login credentials. Please Select One to proceed.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 12),
                          if (controller.error != null) ...[
                            ErrorNotice(controller.error!),
                            const SizedBox(height: 16),
                          ],
                          if (!choosingAccount)
                            for (var i = 0; i < controller.centers.length; i++)
                              Card(
                                child: ListTile(
                                  key: Key('center_$i'),
                                  leading: const Icon(
                                    Icons.local_hospital_outlined,
                                    color: DocColors.greenSea,
                                  ),
                                  title: Text(controller.centers[i].name),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap:
                                      () async => controller.selectCenter(
                                        controller.centers[i],
                                      ),
                                ),
                              ),
                          if (choosingAccount && center != null)
                            for (var i = 0; i < center.accounts.length; i++)
                              Card(
                                child: ListTile(
                                  key: Key('account_$i'),
                                  leading: Icon(
                                    center.accounts[i].role ==
                                            AccountRole.doctor
                                        ? Icons.medical_services_outlined
                                        : Icons.admin_panel_settings_outlined,
                                    color: DocColors.greenSea,
                                  ),
                                  title: Text(center.accounts[i].displayName),
                                  subtitle: Text(
                                    center.accounts[i].role ==
                                            AccountRole.doctor
                                        ? 'Doctor • ${center.accounts[i].department}'
                                        : 'Admin • ${center.accounts[i].adminUserName}',
                                  ),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap:
                                      () async => controller.selectAccount(
                                        center.accounts[i],
                                      ),
                                ),
                              ),
                          const SizedBox(height: 16),
                          if (choosingAccount && controller.centers.length > 1)
                            TextButton(
                              onPressed: controller.backToCenters,
                              child: const Text('Back to centres'),
                            ),
                          TextButton(
                            onPressed: controller.cancelSelection,
                            child: const Text('Cancel'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ErrorNotice extends StatelessWidget {
  const ErrorNotice(this.message, {super.key});
  final String message;

  @override
  Widget build(BuildContext context) => Semantics(
    liveRegion: true,
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0ED),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        message,
        style: const TextStyle(color: Color(0xFFA33220), fontSize: 14),
      ),
    ),
  );
}
