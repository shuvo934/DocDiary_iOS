#!/usr/bin/env python3
"""Download the native screen's font families and their upstream licences.

Font download failure retains system fallbacks, rather than breaking setup.
No font is substituted with another font and called a visual match.
"""
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://raw.githubusercontent.com/google/fonts/main/'
FAMILIES = {
    'Poppins': ('ofl/poppins/', 'OFL.txt', [
        ('Poppins-Regular.ttf', 400), ('Poppins-Medium.ttf', 500),
        ('Poppins-SemiBold.ttf', 600), ('Poppins-Bold.ttf', 700)]),
    'PatuaOne': ('ofl/patuaone/', 'OFL.txt', [('PatuaOne-Regular.ttf', 400)]),
    'Ubuntu': ('ufl/ubuntu/', 'UFL.txt', [('Ubuntu-Medium.ttf', 500)]),
}


def fetch(url, path, font=False):
    if not path.exists():
        with urllib.request.urlopen(url, timeout=12) as response:
            data = response.read(8 * 1024 * 1024)
        if not data or (font and data[:4] not in [b'\x00\x01\x00\x00', b'OTTO', b'ttcf']):
            raise ValueError('Downloaded file is not the expected font data')
        path.write_bytes(data)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install():
    output = ROOT / 'assets/fonts'
    output.mkdir(parents=True, exist_ok=True)
    declarations, manifest = [], []
    for family, (directory, licence, fonts) in FAMILIES.items():
        try:
            fetch(BASE + directory + licence, output / (family + '-' + licence))
            records = []
            for filename, weight in fonts:
                url = BASE + directory + filename
                digest = fetch(url, output / filename, font=True)
                records.append({'file': filename, 'source': url, 'sha256': digest})
            declarations += ['    - family: ' + family, '      fonts:']
            for filename, weight in fonts:
                declarations += ['        - asset: assets/fonts/' + filename,
                                 '          weight: ' + str(weight)]
            manifest += records
        except Exception:
            print('Font download unavailable for ' + family + '. System fallback remains; visual parity is pending.')
    pubspec = ROOT / 'pubspec.yaml'
    marker = '  # BEGIN LOCAL NATIVE FONTS'
    original = pubspec.read_text().split(marker)[0].rstrip()
    if declarations:
        original += '\n' + marker + '\n  fonts:\n' + '\n'.join(declarations)
    pubspec.write_text(original + '\n')
    (output / 'font_sources.json').write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    install()

