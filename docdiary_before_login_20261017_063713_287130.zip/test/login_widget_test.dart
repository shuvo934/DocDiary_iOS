import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:docdiary_ios/app.dart';
import 'package:docdiary_ios/features/auth/auth_controller.dart';
import 'package:docdiary_ios/features/dashboard/dashboard_repository.dart';

import 'support.dart';

void main() {
  Future<Harness> showLogin(WidgetTester tester) async {
    final h = Harness();
    await h.auth.initialize();
    await tester.pumpWidget(
      DocDiaryApp(
        auth: h.auth,
        dashboard: DashboardRepository(h.transport, now: () => h.now),
        initializeOnStart: false,
      ),
    );
    await tester.pumpAndSettle();
    return h;
  }

  testWidgets(
    'login labels, original artwork and password visibility control are present',
    (tester) async {
      await showLogin(tester);
      expect(find.text('WELCOME!'), findsOneWidget);
      expect(find.text('Login to continue'), findsOneWidget);
      expect(find.bySemanticsLabel('DocDiary'), findsOneWidget);
      final password = find.byKey(const Key('password_field'));
      expect(tester.widget<TextField>(password).obscureText, isTrue);
      await tester.ensureVisible(find.byTooltip('Show password'));
      await tester.tap(find.byTooltip('Show password'));
      await tester.pump();
      expect(tester.widget<TextField>(password).obscureText, isFalse);
    },
  );

  testWidgets('empty submission shows validation and sends no request', (
    tester,
  ) async {
    final h = await showLogin(tester);
    await tester.ensureVisible(find.byKey(const Key('login_button')));
    await tester.tap(find.byKey(const Key('login_button')));
    await tester.pumpAndSettle();
    expect(find.text('Please Give Mobile No and Password'), findsOneWidget);
    expect(h.transport.requests, isEmpty);
  });

  testWidgets(
    'successful login enters the correct doctor dashboard and logout returns to login',
    (tester) async {
      final h = await showLogin(tester);
      await tester.enterText(
        find.byKey(const Key('mobile_field')),
        '01700000000',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'test-only-password',
      );
      await tester.ensureVisible(find.byKey(const Key('login_button')));
      await tester.tap(find.byKey(const Key('login_button')));
      await tester.pumpAndSettle();
      expect(h.auth.stage, AuthStage.authenticated);
      expect(find.text('Dr. Example Therapist'), findsOneWidget);
      await tester.tap(find.byKey(const Key('logout_button')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Yes'));
      await tester.pumpAndSettle();
      expect(find.text('WELCOME!'), findsOneWidget);
      expect(h.vault.state.session, isNull);
    },
  );

  testWidgets(
    'small iPhone viewport and open keyboard keep login scrollable without overflow',
    (tester) async {
      tester.view.physicalSize = const Size(320, 568);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await showLogin(tester);
      tester.view.viewInsets = const FakeViewPadding(bottom: 250);
      addTearDown(tester.view.resetViewInsets);
      await tester.pump();
      await tester.ensureVisible(find.byKey(const Key('login_button')));
      expect(tester.takeException(), isNull);
    },
  );
}
