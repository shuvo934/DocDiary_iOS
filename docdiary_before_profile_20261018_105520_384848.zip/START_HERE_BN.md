# নতুন startup/device checkpoint

চলমান Mac project-এ focused Startup Device patch লাগান। সম্পূর্ণ নির্দেশ:
[STARTUP_DEVICE_UPDATE_BN.md](docs/STARTUP_DEVICE_UPDATE_BN.md)। নতুন করে
Flutter project বা iOS Runner তৈরি করতে হবে না। নতুন project setup-এর পুরোনো
নির্দেশ নিচে রাখা হয়েছে।

---

# প্রথমে এটি পড়ুন

এটি DocDiary-এর **আলাদা Flutter iOS project-এর প্রথম ধাপ**। Native Android
project-এর কোনো file পরিবর্তন করা হয়নি। পুরো app এখনো convert হয়নি।

## Mac-এ শুরু

১. ZIP extract করুন। `docdiary_flutter_ios` folder-এ Terminal খুলুন।

২. চালান:

```bash
bash tool/bootstrap_ios.sh
```

এটি আপনার Mac-এর Flutter SDK দিয়ে iOS runner তৈরি করবে, dependencies আনবে এবং
analyzer ও automated tests চালাবে। Flutter/Dart PATH-এ না থাকলে আগে সেটি setup করতে হবে।
কোনো error হলে পরের command-এ এগোনোর আগে সম্পূর্ণ error output দিন।

৩. Checks pass করলে simulator build পরীক্ষা করুন:

```bash
flutter build ios --simulator --debug --no-codesign
```

৪. বাস্তব iPhone-এর জন্য Xcode-এ `ios/Runner.xcworkspace` খুলুন। Runner-এর
Signing & Capabilities থেকে আপনার Team নির্বাচন করুন। তারপর:

```bash
flutter devices
flutter run -d YOUR_IPHONE_DEVICE_ID
```

`YOUR_IPHONE_DEVICE_ID`-এর জায়গায় `flutter devices`-এ দেখানো iPhone ID বসবে।

## এবার যেটুকু পরীক্ষা করব

- Login screen-এর layout, keyboard, password visibility ও Remember Me।
- সঠিক/ভুল login; single centre এবং multiple centre।
- Doctor, admin ও mixed account selection এবং cancel।
- Access/expiry/forced logout-এর আচরণ।
- Dashboard entry-তে সঠিক ব্যক্তি, centre ও summary data।
- Logout, app বন্ধ করে পুনরায় চালানো, account switching।

Dashboard-এর charts, camera/profile ছবি, countdown এবং বাকি module এই package-এ
সম্পূর্ণ হয়নি। সেগুলো complete বলে ধরা যাবে না। Camera ও prescription PDF-এর
iPhone trial-ও এখনো বাকি।

## যাচাইয়ের অবস্থা

এখানে ৪১টি Dart/Flutter test case লেখা হয়েছে; Flutter SDK unavailable থাকায়
সেগুলো এখানে চালানো হয়নি। File consistency এবং iOS setup-script-এর ৬টি Python
test pass করেছে। এই checks iOS build বা real-device testing-এর বিকল্প নয়।

প্রথম manual login-এর জন্য test account ব্যবহার করা ভালো: native app-এর মতো
login-এর সময় server flag, expiry এবং login log update হতে পারে।

পরীক্ষার ফল জানাতে `docs/ACCEPTANCE_CHECKLIST.md` ব্যবহার করুন। কোনো screenshot
বা log পাঠালে password ও রোগীর ব্যক্তিগত তথ্য ঢেকে দিন।

