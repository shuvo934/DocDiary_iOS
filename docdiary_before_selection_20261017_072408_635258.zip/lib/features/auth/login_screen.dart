import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_theme.dart';
import 'auth_controller.dart';
import 'auth_models.dart';
import 'native_login_layout.dart';

export 'native_login_layout.dart' show NativeLoginProgressScreen;

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.controller});
  final AuthController controller;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _mobile = TextEditingController();
  final _password = TextEditingController();
  bool _remember = false;
  bool _hidePassword = true;

  @override
  void initState() {
    super.initState();
    final saved = widget.controller.formCredentials;
    if (saved != null) {
      _mobile.text = saved.mobile;
      _password.text = saved.password;
      _remember = widget.controller.formRemember;
    }
    final initialError = widget.controller.error;
    if (initialError != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.controller.stage == AuthStage.signedOut) {
          unawaited(_showError(initialError));
        }
      });
    }
  }

  @override
  void dispose() {
    _mobile.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (widget.controller.busy) {
      return;
    }
    await widget.controller.login(
      _mobile.text,
      _password.text,
      remember: _remember,
    );
    if (!mounted || widget.controller.stage != AuthStage.signedOut) {
      return;
    }
    final error = widget.controller.error;
    if (error != null) {
      await _showError(error);
    }
  }

  Future<void> _showError(String message) async {
    if (message == 'Please Give Mobile No and Password') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message, textAlign: TextAlign.center),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }
    final retry =
        message == 'Server Problem or Internet Not Connected' ||
        message == 'There is a network issue in the server. Please Try later.';
    final shouldRetry = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Row(
              children: [
                Image.asset(
                  'assets/images/doc_diary_default.png',
                  width: 24,
                  height: 24,
                ),
                const SizedBox(width: 12),
                const Text('Warning!'),
              ],
            ),
            content: Text(message),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, retry),
                child: Text(retry ? 'Retry' : 'OK'),
              ),
            ],
          ),
    );
    if (mounted && shouldRetry == true) {
      await _submit();
    }
  }

  Future<void> _contact() async {
    final approved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder:
          (context) => PopScope(
            canPop: false,
            child: AlertDialog(
              content: const Text(
                'Do you want to send an email to info@techterrain-it.com ?',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('No'),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Yes'),
                ),
              ],
            ),
          ),
    );
    if (approved != true || !mounted) return;
    const body =
        'Please fill out the field to create your user id.\n\n'
        'Center/Hospital Name: \nCenter/Hospital Address: \nUser Name: \n'
        'User Mobile No: \nUser Designation: \nUser Mail: \nUser Code(If any): ';
    final uri = Uri(
      scheme: 'mailto',
      path: 'info@techterrain-it.com',
      query:
          'subject=${Uri.encodeComponent('New Account Creation Request From DocDiary')}'
          '&body=${Uri.encodeComponent(body)}',
    );
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('There is no email app found.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('There is no email app found.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.controller.busy) {
      return const NativeLoginProgressScreen();
    }
    return NativeLoginLayout(
      mobile: _mobile,
      password: _password,
      remember: _remember,
      hidePassword: _hidePassword,
      onRememberChanged: (value) => setState(() => _remember = value),
      onTogglePassword: () => setState(() => _hidePassword = !_hidePassword),
      onDone: () => FocusScope.of(context).unfocus(),
      onSubmit: () => unawaited(_submit()),
      onContact: () => unawaited(_contact()),
    );
  }
}

class SelectionScreen extends StatelessWidget {
  const SelectionScreen({super.key, required this.controller});
  final AuthController controller;

  @override
  Widget build(BuildContext context) {
    final center = controller.selectedCenter;
    final choosingAccount = controller.stage == AuthStage.chooseAccount;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black38,
        body: SafeArea(
          child: Center(
            child: Dialog(
              insetPadding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: 560,
                  maxHeight: MediaQuery.sizeOf(context).height * .82,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      color: DocColors.primary,
                      padding: const EdgeInsets.only(left: 16),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.local_hospital_outlined,
                            color: Colors.white,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              choosingAccount && center != null
                                  ? center.name
                                  : 'SELECT CENTER',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Cancel selection',
                            icon: const Icon(Icons.close, color: Colors.white),
                            onPressed: controller.cancelSelection,
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(12),
                        children: [
                          Text(
                            choosingAccount
                                ? 'We have found Multiple USER ID for your login credentials. Please Select One to proceed.'
                                : 'We have found Multiple Center for your login credentials. Please Select One to proceed.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 12),
                          if (controller.error != null) ...[
                            ErrorNotice(controller.error!),
                            const SizedBox(height: 16),
                          ],
                          if (!choosingAccount)
                            for (var i = 0; i < controller.centers.length; i++)
                              Card(
                                child: ListTile(
                                  key: Key('center_$i'),
                                  leading: const Icon(
                                    Icons.local_hospital_outlined,
                                    color: DocColors.greenSea,
                                  ),
                                  title: Text(controller.centers[i].name),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap:
                                      () async => controller.selectCenter(
                                        controller.centers[i],
                                      ),
                                ),
                              ),
                          if (choosingAccount && center != null)
                            for (var i = 0; i < center.accounts.length; i++)
                              Card(
                                child: ListTile(
                                  key: Key('account_$i'),
                                  leading: Icon(
                                    center.accounts[i].role ==
                                            AccountRole.doctor
                                        ? Icons.medical_services_outlined
                                        : Icons.admin_panel_settings_outlined,
                                    color: DocColors.greenSea,
                                  ),
                                  title: Text(center.accounts[i].displayName),
                                  subtitle: Text(
                                    center.accounts[i].role ==
                                            AccountRole.doctor
                                        ? 'Doctor • ${center.accounts[i].department}'
                                        : 'Admin • ${center.accounts[i].adminUserName}',
                                  ),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap:
                                      () async => controller.selectAccount(
                                        center.accounts[i],
                                      ),
                                ),
                              ),
                          const SizedBox(height: 16),
                          if (choosingAccount && controller.centers.length > 1)
                            TextButton(
                              onPressed: controller.backToCenters,
                              child: const Text('Back to centres'),
                            ),
                          TextButton(
                            onPressed: controller.cancelSelection,
                            child: const Text('Cancel'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ErrorNotice extends StatelessWidget {
  const ErrorNotice(this.message, {super.key});
  final String message;

  @override
  Widget build(BuildContext context) => Semantics(
    liveRegion: true,
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0ED),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        message,
        style: const TextStyle(color: Color(0xFFA33220), fontSize: 14),
      ),
    ),
  );
}
