import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/app_theme.dart';
import '../../core/failure.dart';
import '../../core/native_dates.dart';
import '../auth/auth_controller.dart';
import '../auth/login_screen.dart';
import '../auth/profile_repository.dart';
import 'dashboard_repository.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.auth,
    required this.repository,
  });
  final AuthController auth;
  final DashboardRepository repository;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with WidgetsBindingObserver {
  late AccountProfile _profile;
  DashboardSummary? _summary;
  SummaryPeriod _period = SummaryPeriod.today;
  String? _error;
  bool _loading = false;
  int _request = 0;

  @override
  void initState() {
    super.initState();
    _profile = widget.auth.profile!;
    WidgetsBinding.instance.addObserver(this);
    // The account was already checked by AuthController before entering here.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (mounted) await _load(revalidate: false);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_loading) {
      unawaited(_load());
    }
  }

  Future<void> _load({bool revalidate = true}) async {
    if (!mounted || _loading) return;
    final session = widget.auth.session;
    if (session == null) return;
    final request = ++_request;
    setState(() {
      _loading = true;
      _error = null;
      _summary = null;
    });
    try {
      final profile =
          revalidate
              ? await widget.auth.profiles.open(session, recordLogin: false)
              : _profile;
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      final result = await widget.repository.load(session, profile, _period);
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      setState(() {
        _profile = profile;
        _summary = result;
      });
    } catch (failure) {
      if (!mounted || request != _request || widget.auth.session != session) {
        return;
      }
      if (failure is AppFailure && failure.kind == FailureKind.denied) {
        await widget.auth.logout(message: failure.message);
        return;
      }
      setState(
        () =>
            _error =
                failure is AppFailure
                    ? failure.message
                    : 'Dashboard data could not be loaded. Please try again.',
      );
    } finally {
      if (mounted && request == _request) setState(() => _loading = false);
    }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Log Out!'),
            content: const Text('Do you want to log out?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Yes'),
              ),
            ],
          ),
    );
    if (confirmed == true && mounted) await widget.auth.logout();
  }

  @override
  void dispose() {
    ++_request;
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final range = SummaryRange.forPeriod(_period, DateTime.now());
    final summary = _summary;
    return Scaffold(
      backgroundColor: DocColors.clouds,
      appBar: AppBar(
        title: const Text(
          'Dashboard',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
        ),
        leading: Padding(
          padding: const EdgeInsets.all(12),
          child: Image.asset('assets/images/doc_diary_default.png'),
        ),
        actions: [
          if (widget.auth.canSwitch)
            IconButton(
              key: const Key('switch_account'),
              tooltip: 'Switch user',
              onPressed: widget.auth.beginSwitch,
              icon: const Icon(Icons.switch_account_outlined),
            ),
          IconButton(
            key: const Key('logout_button'),
            tooltip: 'Log Out',
            onPressed: _logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 840),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                greeting(DateTime.now()),
                                style: const TextStyle(
                                  color: DocColors.greenSea,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 7),
                              Text(
                                _profile.displayName,
                                key: const Key('account_name'),
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 7),
                              Text(
                                _profile.centerName.isEmpty
                                    ? widget.auth.session!.center.name
                                    : _profile.centerName,
                                key: const Key('center_name'),
                                style: const TextStyle(
                                  color: Color(0xFF0097E6),
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        CircleAvatar(
                          radius: 28,
                          backgroundColor: DocColors.clouds,
                          backgroundImage: const AssetImage(
                            'assets/images/doctor.png',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (final period in SummaryPeriod.values)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(period.label),
                              selected: _period == period,
                              selectedColor: DocColors.primary,
                              onSelected:
                                  _loading
                                      ? null
                                      : (selected) async {
                                        if (selected && period != _period) {
                                          setState(() => _period = period);
                                          await _load();
                                        }
                                      },
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '${oracleDate(range.first)}  --  ${oracleDate(range.last)}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF6C6E6F),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_loading)
                    const Padding(
                      padding: EdgeInsets.all(36),
                      child: Center(child: CircularProgressIndicator()),
                    ),
                  if (_error != null) ...[
                    ErrorNotice(_error!),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () async => _load(),
                      child: const Text('Retry'),
                    ),
                  ],
                  if (summary != null) ...[
                    if (_profile.isDoctor) ...[
                      _StatsRow(
                        values: summary.values.entries.take(2).toList(),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Appointment',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: DocColors.greenSea,
                          fontSize: 17,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _StatsRow(
                        values: summary.values.entries.skip(2).toList(),
                      ),
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: DocColors.greenSea,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Next Meeting',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              summary.nextTime.isEmpty
                                  ? 'No upcoming meeting'
                                  : summary.nextTime,
                              style: const TextStyle(color: Colors.white),
                            ),
                            if (summary.nextPatient.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Text(
                                  summary.nextPatient,
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ] else ...[
                      _StatsRow(
                        values: summary.values.entries.take(2).toList(),
                      ),
                      const SizedBox(height: 12),
                      _StatsRow(
                        values: summary.values.entries.skip(2).toList(),
                      ),
                    ],
                  ],
                  const SizedBox(height: 28),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  const _StatsRow({required this.values});
  final List<MapEntry<String, String>> values;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      for (var i = 0; i < values.length; i++)
        Expanded(
          child: Container(
            constraints: const BoxConstraints(minHeight: 132),
            margin: EdgeInsets.only(right: i == values.length - 1 ? 0 : 8),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                colors:
                    i.isEven
                        ? [DocColors.primary, DocColors.greenSea]
                        : [const Color(0xFF879AF2), const Color(0xFF596275)],
              ),
            ),
            child: Column(
              children: [
                Text(
                  values[i].key,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 13),
                Text(
                  values[i].value,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
    ],
  );
}
