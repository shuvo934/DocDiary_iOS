import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_theme.dart';
import '../../core/native_json.dart';
import '../appointments/doctor_schedule/native_appointment_timeline_card.dart';
import 'normal_prescription_models.dart';

/// Shares the native header and safe-area structure with Progress/History.
class NormalPrescriptionShell extends StatelessWidget {
  const NormalPrescriptionShell({
    super.key,
    required this.title,
    required this.child,
    required this.onBack,
    this.waiting = false,
  });
  final String title;
  final Widget child;
  final VoidCallback? onBack;
  final bool waiting;
  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
    value: SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.white,
    ),
    child: Scaffold(
      backgroundColor: DocColors.primary,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: math.max(
                  52,
                  (MediaQuery.sizeOf(context).height -
                          MediaQuery.paddingOf(context).vertical) *
                      .09,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                child: Row(
                  children: [
                    IconButton(
                      key: const Key('normal_prescription_back'),
                      tooltip: 'Back',
                      onPressed: onBack,
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: appointmentText(
                          16,
                          weight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 5),
            Expanded(
              child: Material(
                color: Colors.white,
                clipBehavior: Clip.antiAlias,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
                child: SafeArea(
                  top: false,
                  child: SizedBox.expand(
                    child:
                        waiting
                            ? const Center(
                              child: CircularProgressIndicator(
                                key: Key('normal_prescription_loading'),
                                color: DocColors.primary,
                              ),
                            )
                            : child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class NativeNormalPrescriptionLayout extends StatelessWidget {
  const NativeNormalPrescriptionLayout({
    super.key,
    required this.seed,
    required this.snapshot,
    required this.rows,
    required this.onCreate,
    required this.onEdit,
    required this.onDelete,
    required this.onSelect,
    required this.onAdmission,
    required this.onHistoryTab,
    required this.onTreatmentTab,
    required this.onReload,
    this.enabled = true,
    this.historyTab = 0,
    this.treatmentTab = 0,
    this.diagnosis,
    this.referral,
    this.message,
  });
  final NormalPrescriptionSeed seed;
  final NormalPrescriptionSnapshot? snapshot;
  final Map<NormalPrescriptionSection, List<JsonMap>> rows;
  final VoidCallback onCreate, onReload;
  final void Function(NormalPrescriptionSection, JsonMap?) onEdit;
  final void Function(NormalPrescriptionSection, JsonMap) onDelete, onSelect;
  final ValueChanged<bool> onAdmission;
  final ValueChanged<int> onHistoryTab, onTreatmentTab;
  final bool enabled;
  final int historyTab, treatmentTab;
  final JsonMap? diagnosis, referral;
  final String? message;

  Widget _readonly(String label, String value) => InputDecorator(
    decoration: InputDecoration(
      labelText: label,
      floatingLabelBehavior: FloatingLabelBehavior.always,
      labelStyle: const TextStyle(fontSize: 12, color: Colors.black54),
      filled: false,
      contentPadding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.black38),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.black38),
      ),
    ),
    child: Text(
      value.isEmpty ? ' ' : value,
      style: appointmentText(13, color: Colors.black, weight: FontWeight.w700),
    ),
  );
  Widget _pair(String a, String b, String c, String d) => Padding(
    padding: const EdgeInsets.only(top: 12),
    child: IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(child: _readonly(a, b)),
          const SizedBox(width: 12),
          Expanded(child: _readonly(c, d)),
        ],
      ),
    ),
  );
  Widget _heading(String label) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: Row(
      children: [
        const Expanded(child: Divider()),
        const SizedBox(width: 6),
        Flexible(
          flex: 4,
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: appointmentText(
              14,
              weight: FontWeight.w700,
              color: DocColors.greenSea,
            ),
          ),
        ),
        const SizedBox(width: 6),
        const Expanded(child: Divider()),
      ],
    ),
  );
  Widget _tabs(
    List<NormalPrescriptionSection> values,
    int selected,
    ValueChanged<int> changed,
  ) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      for (var i = 0; i < values.length; i++)
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: Material(
              color: i == selected ? DocColors.primary : DocColors.clouds,
              child: InkWell(
                key: Key('rx_tab_${values[i].name}'),
                onTap: enabled ? () => changed(i) : null,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 3,
                    vertical: 10,
                  ),
                  child: Text(
                    rxSectionSpecs[values[i]]!.label,
                    textAlign: TextAlign.center,
                    style: appointmentText(
                      12,
                      color: i == selected ? Colors.white : Colors.black,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
    ],
  );

  Widget _table(BuildContext context, NormalPrescriptionSection kind) {
    final spec = rxSectionSpecs[kind]!,
        values = rows[kind] ?? const <JsonMap>[];
    final selected =
        kind == NormalPrescriptionSection.diagnosis
            ? diagnosis
            : kind == NormalPrescriptionSection.referral
            ? referral
            : null;
    final canSelect =
        kind == NormalPrescriptionSection.diagnosis ||
        kind == NormalPrescriptionSection.referral;
    return Card(
      key: Key('rx_section_${kind.name}'),
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(color: DocColors.primary, width: .7),
      ),
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LayoutBuilder(
            builder:
                (context, bounds) => SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minWidth: bounds.maxWidth),
                    child: DataTable(
                      showCheckboxColumn: false,
                      columnSpacing: 12,
                      horizontalMargin: 12,
                      dataRowMinHeight: 42,
                      dataRowMaxHeight: double.infinity,
                      headingRowHeight: 55,
                      headingRowColor: const WidgetStatePropertyAll(
                        DocColors.primary,
                      ),
                      columns: [
                        for (final field in spec.fields)
                          DataColumn(
                            label: SizedBox(
                              width: field.isChoice ? 115 : 100,
                              child: Text(
                                field.label,
                                style: appointmentText(
                                  12,
                                  color: Colors.white,
                                  weight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        if (!seed.readOnly) const DataColumn(label: Text('')),
                      ],
                      rows: [
                        for (final row in values)
                          DataRow(
                            key: ValueKey(
                              'rx_row_${kind.name}_${rxValue(row, spec.rowId)}',
                            ),
                            selected:
                                selected != null &&
                                rxValue(selected, spec.rowId) ==
                                    rxValue(row, spec.rowId),
                            onSelectChanged:
                                canSelect && enabled
                                    ? (_) => onSelect(kind, row)
                                    : null,
                            cells: [
                              for (final f in spec.fields)
                                DataCell(
                                  SizedBox(
                                    width: f.isChoice ? 115 : 100,
                                    child: Text(
                                      f.display(row),
                                      style: appointmentText(12),
                                    ),
                                  ),
                                ),
                              if (!seed.readOnly)
                                DataCell(
                                  rxMayModify(spec, row)
                                      ? Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          IconButton(
                                            key: Key(
                                              'rx_edit_${kind.name}_${rxValue(row, spec.rowId)}',
                                            ),
                                            tooltip: 'Edit',
                                            onPressed:
                                                enabled
                                                    ? () => onEdit(kind, row)
                                                    : null,
                                            icon: const Icon(
                                              Icons.edit,
                                              size: 20,
                                              color: DocColors.greenSea,
                                            ),
                                          ),
                                          IconButton(
                                            key: Key(
                                              'rx_delete_${kind.name}_${rxValue(row, spec.rowId)}',
                                            ),
                                            tooltip: 'Delete',
                                            onPressed:
                                                enabled
                                                    ? () => onDelete(kind, row)
                                                    : null,
                                            icon: const Icon(
                                              Icons.delete_outline,
                                              size: 20,
                                              color: Colors.redAccent,
                                            ),
                                          ),
                                        ],
                                      )
                                      : const SizedBox.shrink(),
                                ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
          ),
          if (values.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No Information Found', textAlign: TextAlign.center),
            ),
          if (canSelect && values.isNotEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Text(
                'Tap a row to view its details.',
                style: TextStyle(fontSize: 11, color: Colors.black54),
              ),
            ),
          if (!seed.readOnly)
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: TextButton(
                  key: Key('rx_add_${kind.name}'),
                  onPressed: enabled ? () => onEdit(kind, null) : null,
                  child: const Text('ADD'),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (snapshot == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                message ?? 'Prescription data is unavailable.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              TextButton(
                key: const Key('rx_reload'),
                onPressed: onReload,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    final patient = snapshot!.patient;
    const history = [
      NormalPrescriptionSection.medicalHistory,
      NormalPrescriptionSection.drugHistory,
      NormalPrescriptionSection.clinicalFindings,
    ];
    const treatment = [
      NormalPrescriptionSection.management,
      NormalPrescriptionSection.medication,
      NormalPrescriptionSection.advice,
      NormalPrescriptionSection.reference,
    ];
    return SingleChildScrollView(
      key: const Key('rx_scroll'),
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            rxValue(patient, 'pat_name'),
            key: const Key('rx_patient_name'),
            textAlign: TextAlign.center,
            style: appointmentText(
              16,
              weight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          Text(
            rxValue(patient, 'ph_sub_code'),
            textAlign: TextAlign.center,
            style: appointmentText(12),
          ),
          const SizedBox(height: 14),
          if (seed.readOnly)
            const Text(
              'View only',
              key: Key('rx_view_only'),
              textAlign: TextAlign.center,
              style: TextStyle(color: DocColors.greenSea),
            ),
          _readonly('MDT Code:', rxValue(patient, 'pmm_code')),
          _pair(
            'Age:',
            rxValue(patient, 'pat_age'),
            'Marital Status:',
            rxValue(patient, 'marital_status'),
          ),
          _pair(
            'Gender:',
            rxValue(patient, 'gender'),
            'Blood Group:',
            rxValue(patient, 'pat_blood'),
          ),
          _pair(
            'Patient Category:',
            rxValue(patient, 'pat_category_name'),
            'Patient Status:',
            rxValue(patient, 'ph_patient_status'),
          ),
          const SizedBox(height: 12),
          _readonly('Address:', rxValue(patient, 'address')),
          const SizedBox(height: 14),
          if (!snapshot!.exists) ...[
            if (seed.readOnly)
              const Text(
                'No Prescription Found',
                key: Key('rx_no_prescription'),
                textAlign: TextAlign.center,
              )
            else
              ElevatedButton(
                key: const Key('rx_create'),
                onPressed: enabled ? onCreate : null,
                child: const Text('Create Prescription'),
              ),
          ] else ...[
            _heading('INJURY DETAILS'),
            _table(context, NormalPrescriptionSection.complain),
            _heading('PAST MEDICAL INFORMATION'),
            _tabs(history, historyTab, onHistoryTab),
            _table(context, history[historyTab]),
            _heading('DIAGNOSIS DETAILS'),
            _table(context, NormalPrescriptionSection.diagnosis),
            if (diagnosis != null) ...[
              const SizedBox(height: 8),
              Text(
                'Referral Unit — ${rxValue(diagnosis!, "dm_name")}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              _table(context, NormalPrescriptionSection.referral),
              if (referral != null) ...[
                const SizedBox(height: 8),
                Text(
                  'Services — ${rxValue(referral!, "depts_name")}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                _table(context, NormalPrescriptionSection.service),
              ],
            ],
            _heading('PRESCRIPTION DETAILS'),
            _tabs(treatment, treatmentTab, onTreatmentTab),
            _table(context, treatment[treatmentTab]),
            CheckboxListTile(
              key: const Key('rx_admission'),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: rxValue(patient, 'pmm_admission_flag') == '1',
              onChanged:
                  !seed.readOnly && enabled
                      ? (v) => onAdmission(v ?? false)
                      : null,
              title: Text(
                'Allow this Check Box for Patient Admission',
                style: appointmentText(12),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

InputDecoration rxInputDecoration(String label) => InputDecoration(
  labelText: label,
  filled: false,
  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: const BorderSide(color: Colors.black38),
  ),
);

class NativeNormalPrescriptionEditor extends StatelessWidget {
  const NativeNormalPrescriptionEditor({
    super.key,
    required this.spec,
    required this.controllers,
    required this.onPick,
    required this.onChanged,
    required this.onSave,
    required this.onCancel,
    this.enabled = true,
  });
  final RxSectionSpec spec;
  final Map<String, TextEditingController> controllers;
  final ValueChanged<RxField> onPick;
  final void Function(RxField, String) onChanged;
  final VoidCallback onSave, onCancel;
  final bool enabled;
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    key: const Key('rx_editor'),
    padding: const EdgeInsets.all(20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final field in spec.fields)
          Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child:
                field.isChoice || field.isDate
                    ? TextField(
                      key: Key('rx_field_${field.header}'),
                      controller: controllers[field.header],
                      readOnly: true,
                      onTap: enabled ? () => onPick(field) : null,
                      decoration: rxInputDecoration(
                        field.label + (field.required ? ' *' : ''),
                      ).copyWith(suffixIcon: const Icon(Icons.arrow_drop_down)),
                    )
                    : Column(
                      children: [
                        TextField(
                          key: Key('rx_field_${field.header}'),
                          controller: controllers[field.header],
                          enabled: enabled,
                          keyboardType:
                              field.numeric
                                  ? const TextInputType.numberWithOptions(
                                    decimal: true,
                                  )
                                  : TextInputType.text,
                          decoration: rxInputDecoration(
                            field.label + (field.required ? ' *' : ''),
                          ),
                          onChanged: (v) => onChanged(field, v),
                        ),
                        if (field.lookup.isNotEmpty)
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              key: Key('rx_suggest_${field.header}'),
                              onPressed: enabled ? () => onPick(field) : null,
                              child: const Text(
                                'Choose from saved suggestions',
                              ),
                            ),
                          ),
                      ],
                    ),
          ),
        ElevatedButton(
          key: const Key('rx_save'),
          onPressed: enabled ? onSave : null,
          child: const Text('Save'),
        ),
        const SizedBox(height: 8),
        TextButton(
          onPressed: enabled ? onCancel : null,
          child: const Text('Cancel'),
        ),
      ],
    ),
  );
}

class RxChoiceDialog extends StatefulWidget {
  const RxChoiceDialog({super.key, required this.field, required this.choices});
  final RxField field;
  final List<RxChoice> choices;
  @override
  State<RxChoiceDialog> createState() => _RxChoiceDialogState();
}

class _RxChoiceDialogState extends State<RxChoiceDialog> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final matches =
        widget.choices
            .where(
              (c) => c.description.toLowerCase().contains(query.toLowerCase()),
            )
            .toList();
    return AlertDialog(
      scrollable: true,
      title: Text(widget.field.label),
      content: SizedBox(
        width: 420,
        height: math.min(420, MediaQuery.sizeOf(context).height * .5),
        child: Column(
          children: [
            TextField(
              key: const Key('rx_choice_search'),
              decoration: const InputDecoration(hintText: 'Search'),
              onChanged: (v) => setState(() => query = v),
            ),
            const SizedBox(height: 8),
            Expanded(
              child:
                  matches.isEmpty
                      ? const Center(child: Text('No options found'))
                      : ListView.builder(
                        itemCount: matches.length,
                        itemBuilder: (context, index) {
                          final choice = matches[index];
                          return ListTile(
                            key: Key('rx_choice_${choice.id}'),
                            title: Text(choice.name),
                            subtitle:
                                choice.note.isEmpty ? null : Text(choice.note),
                            onTap: () => Navigator.pop(context, choice),
                          );
                        },
                      ),
            ),
          ],
        ),
      ),
      actions: [
        if (!widget.field.required)
          TextButton(
            onPressed: () => Navigator.pop(context, const RxChoice('', '')),
            child: const Text('Clear'),
          ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}
