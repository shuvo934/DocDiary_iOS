# Normal Prescription

একটি shared screen ও repository দিয়ে native PrescriptionSetup এবং PatPrescriptionV-এর normal prescription flow যুক্ত করা হয়েছে।

| Entry | আচরণ |
| --- | --- |
| Appointment → Create Prescription / Prescription | Patient তথ্য দেখা, master create, section data add/edit/delete ও Patient Admission flag পরিবর্তন |
| Dashboard → Patient (normal PatientSearch) | Year নির্বাচন, name/code search এবং একই prescription screen-এ view only |

PatientSearch থেকে master create, add, edit, delete বা admission পরিবর্তনের controls নেই। Repository-ও view-only seed দিয়ে কোনো mutation request পাঠায় না। Server-এর access control পরিবর্তন হয়নি।

## Prescription-এর অংশ

Injury Details; Medical History, Drug History ও Clinical Findings tabs; Diagnosis; নির্বাচিত Diagnosis-এর Referral Unit; নির্বাচিত Referral-এর Service; Management, Medication, Advice ও Reference tabs; Patient Admission flag।

Native-এর মতো প্রতিটি section আলাদা করে সংরক্ষিত হয়; পুরো prescription-এর জন্য একবারে draft-save নয়। Master না থাকলে Appointment-এ Create Prescription, PatientSearch-এ No Prescription Found দেখায়। দীর্ঘ existing notes সম্পূর্ণ wrap করে; table horizontally ও পুরো screen vertically scroll করা যায়।

Diagnosis বা Referral-এর child_count শূন্য না হলে native-এর মতো parent edit/delete বন্ধ। Child Service/Referral সরানোর পরে parent বদলানো যাবে। এটি পুরো prescription master delete নয়; native-এর section-row deletion।

Lookup option name-এর সঙ্গে তার ID রাখা হয়। একই নামের doctor বা diagnosis-এ আংশিক/name matching করে ID বেছে নেওয়া হয় না। Referral Doctor-এর code/description দিয়ে option আলাদা করা যায়; Unit বদলালে আগের doctor selection সরে যায়।

## API ও আচরণ

নতুন endpoint দরকার নেই। Native-এর prescription/* এবং patient_search/* endpoint, query parameter, header name ও `Successfully Created` response contract বজায় আছে। Native-এর ৩৫টি mutation endpoint-এর header list test fixture-এ রাখা হয়েছে।

PatientSearch-এর all_presc ও doc_head_flag অনুযায়ী scope এবং 1950 থেকে বর্তমান বছরের range রাখা হয়েছে।

Master create ও সব mutation-এর আগে account/profile recheck হয়, login-entry POST হয় না। Write-এর আগে master/row/parent পুনরায় পড়া হয়। একই add-এর response হারিয়ে গেলে saved row আগে থেকে পাওয়া গেলে duplicate POST বাদ যায়। Account/centre বদলানো, suspended request বা background অবস্থার stale result নতুন screen-এ বসে না।

Save/Delete confirmation ছাড়া write হয় না। Double tap ও একই repository-তে concurrent write বন্ধ। Request ব্যর্থ হলে স্বয়ংক্রিয় POST retry হয় না। Draft screen-এ থাকে; Reload saved data দিয়ে ফল যাচাইয়ের পর প্রয়োজন হলে আবার save করা যায়। Background থেকে resume-এ read refresh হয়, write replay নয়। Feedback আগের common Fluttertoast helper ব্যবহার করে; নতুন Snackbar নেই। Loading spinner সাদা content-এর ওপর থাকে।

Normal native API text HTTP header-এ গ্রহণ করে। নতুন free text এক লাইনে এবং header-এ পাঠানো যায় এমন characters-এ সীমাবদ্ধ; multiline/non-Latin header input স্পষ্ট validation message দেখায়। Existing বাংলা/multiline content দেখা যায়। UTF-8 notes সংরক্ষণের জন্য backend-এ verified JSON/body contract লাগবে; Dynamic Prescription-এর body API এ ধাপে ব্যবহার করা হয়নি।

## সীমা ও যাচাই

Dynamic Prescription-এর route/implementation এই ধাপে বদলায়নি। বিদ্যমান Timeline, History/Progress, Profile, Daily Attendance, SafeArea, spacing, toast এবং loading fix-এর source বজায় আছে। নতুন package/native plugin যোগ করা হয়নি।

Flutter analyzer এবং ১,২৪৮টি test পাস। এগুলো fixture/mocked transport ও Flutter widget tests; production patient data পরিবর্তন করা হয়নি। Xcode/iPhone build, centre-এর live ORDS API ও বাস্তব appearance আপনার Mac-এ যাচাই করতে হবে।
