# Snackbar locations — 25 October 2026

Current source scan: **13 direct showSnackBar call sites in 10 Dart files**. Some sites are shared notice helpers, so several messages use one call site. Line numbers are for this package; formatting or later edits can move them.

Fluttertoast migration is deferred to the next step. No dependency or notification implementation was changed by this inventory. Keep confirmation and Retry/Exit/Cancel dialogs: these require a user decision and are not toast messages.

| File | Line | Context |
| --- | ---: | --- |
| `lib/features/appointments/doctor_schedule/doctor_appointment_screen.dart` | 297 | Video link unavailable |
| `lib/features/appointments/doctor_schedule/doctor_appointment_screen.dart` | 415 | AVAIL outcome |
| `lib/features/appointments/doctor_schedule/progress/doctor_progress_screen.dart` | 261 | Progress validation / success / stale schedule notices via _notice |
| `lib/features/auth/login_screen.dart` | 73 | Missing mobile/password validation |
| `lib/features/auth/login_screen.dart` | 153 | Email app unavailable |
| `lib/features/auth/login_screen.dart` | 159 | Email app launch failure |
| `lib/features/dashboard/dashboard_screen.dart` | 905 | Picture Uploaded |
| `lib/features/dashboard/native_camera_screen.dart` | 165 | Camera notices |
| `lib/features/hr/attendance_update_approval/attendance_approval_screen.dart` | 390 | Attendance approval result notices |
| `lib/features/hr/leave_approval/leave_approval_screen.dart` | 442 | Leave approval result notices |
| `lib/features/profile/doctor_address_screen.dart` | 320 | Address notices via _notice |
| `lib/features/profile/doctor_password_screen.dart` | 222 | Password notices via _notice |
| `lib/features/profile/doctor_profile_screen.dart` | 242 | Profile/photo notices via _notice |

To refresh the inventory:

```bash
rg -n 'showSnackBar|SnackBar\(' lib
```

For migration, preserve each notice trigger and its access/lifecycle checks; decide toast duration/position consistently, and update widget expectations together with implementation. Source files already in this package can be searched directly; only additional local edits need to be merged from the user's current files.
