# Leave Record — iOS conversion

Update, 24 October 2026: **Leave Balance এখন যুক্ত হয়েছে**। Processed/non-pending
row সরাসরি selected employee-এর balance খুলবে। নিচের পুরোনো module-boundary
নোটে Leave Balance-কে ভবিষ্যৎ বলা হয়েছিল; সেটি এখন `LEAVE_BALANCE_BN.md` দিয়ে
হালনাগাদ হয়েছে। Pending row-এর Leave Approval এখনো পরের module।

HR menu → Leave Record এবং HR weekly-leave panel-এর **More Info** থেকে
এই screen খুলবে। Feature-এর code `lib/features/hr/leave_record/`-এ।

## আপনার সর্বশেষ UI edit

24 October-এ দেওয়া `native_attendance_approval_layout(1).dart` হুবহু রাখা হয়েছে।
সর্বশেষ `native_attendance_request_dialog(2).dart`-এর fixed search/header/CANCEL,
rows-only scrolling, Clouds background, black87 text, elevation ও keyboard
settings রাখা হয়েছে। শুধু খুব ছোট viewport/বড় font-এর জন্য middle body-তে
overflow-safe outer scroll fallback যোগ হয়েছে। সাধারণ screen-এ এটি আসে না।

ভবিষ্যৎ Leave Approval selection dialog-এর reference:
`docs/HR_DIALOG_STYLE_REFERENCE.md` এবং বর্তমান attendance request dialog।

## Native source mapping

- `LeaveRecord.java`: month/branch reads, local filters, count dialog, errors,
  row-click parameters।
- `LeaveRecordAdapter.java`, `LeaveRecList.java`: date suffix/range, status,
  employee/location, leave days।
- `activity_leave_record.xml`, `leave_record_details_view.xml` এবং
  `border_design.xml`: four-column layout, colours, border, spacing ও fonts।
- Division/Department/Employee field আগের approved shared HR filter style
  ব্যবহার করে; disabled field-এ একই gray fill।

## Reads এবং filters

সব request নির্বাচিত centre-এর `hrm_dashboard/`-এ GET। এই module backend-এ
কোনো record create/update করে না এবং login log আবার পাঠায় না।

| Action | Native request order |
| --- | --- |
| Initial / None branch | getBranches → getDivision → getDepartment → getEmployee → getLeaveRecord |
| Select branch | getDivisionWithCoa → getDepartmentWithCoa → getEmployeeWithCoa → getLeaveRecordWithCoa |
| Month OK | শুধু getLeaveRecord / getLeaveRecordWithCoa |
| Month CANCEL / local filter | নতুন HR request নেই |

Scoped request-এ `p_coa_id` থাকে। Record read-এ `first_date`, `last_date`;
unscoped request-এ branch parameter নেই। Native None sentinel `30`-ও চেনা হয়।
Division → Department → Employee local cascade ব্যবহার করে। Ancestor clear/change
করলে নিচের selection clear হয়। একই নামের employee ID দিয়ে আলাদা থাকে।
Month বদলালে valid filter থাকে; branch বদলালে clear হয়।

Native picker-এর `Calendar` calculation অক্ষুণ্ণ রাখা হয়েছে: শুরু current month
থেকে দুই মাস আগে; শেষ next month-এ current month's last-day দিয়ে হিসাব করা।
এ কারণে 31-day month-এর পরে ছোট month থাকলে Java-এর lenient rollover-এর মতো
আরও এক মাস দেখা যায়। যেমন October 2026-এ August–December, January 2026-এ
November 2025–March 2026। API-তে নির্বাচিত মাসের প্রথম/শেষ সম্পূর্ণ দিন যায়।

**STATUS** চাপলে filter করা application-এর total/pending/approved/rejected/
cancel-approved count দেখায়; leave days যোগ করে count হয় না। No-data-তেও
summary খুলে zero count দেখা যায়।

Profile/access check entry, refresh, foreground ও row opening-এর আগে চলে।
Stale response screen-এ ফিরে আসে না। Error-এ Retry ঠিক সেই read চালায়;
Cancel আগের screen-এ ফেরে। Logout/background-এ owned popup বন্ধ হয়।

## Row click এবং পরের module

Leave Balance ও Leave Approval screen এখনো এই patch-এর অংশ নয়। তাই default
row click-এ সংশ্লিষ্ট module-এর unavailable dialog আসবে। এইটিকে completed
approval/balance flow ধরে নেবেন না। তাদের screen তৈরি হলে বর্তমান route hook
সরাসরি যুক্ত করা যাবে; custom destination দিয়ে automated test করা হয়েছে।

| Row | Destination | Native extras |
| --- | --- | --- |
| Pending (`0`) | Leave Approval | LA_ID, LA_EMP_ID, LA_APP_CODE, FLAG=1 |
| Other status | Leave Balance | COA_ID, DIV_ID, DEPT_ID, DESIG_ID, EMP_ID, LAST_DATE |

HR menu দিয়ে Leave Approval খুললে তার native FLAG=0 থাকবে; record দিয়ে FLAG=1।
পরের ছোট module হিসেবে **Leave Balance**, তারপর **Leave Approval** করা যাবে।

## Mac-এ apply এবং পরীক্ষা

ZIP extract করে existing `docdiary_ios` project-এর Terminal-এ:

```bash
python3 ~/Downloads/DocDiary_Leave_Record_Patch/apply_leave_record_patch.py .
bash tool/verify.sh --ios-simulator
flutter run -t lib/main.dart
```

Project নতুন করে create/download/replace করতে হবে না। Patch আগে সব target
পরীক্ষা করে, backup রাখে, তারপর শুধু feature-সংক্রান্ত file লেখে।
HR dashboard navigation এবং তার একটি পুরোনো availability test-এ ছোট merge
করবে; বাইরের local edit রাখবে। সর্বশেষ uploaded UI ও আগের delivered UI চেনে।
অচেনা target edit থাকলে কোনো file না বদলে conflict দেখায়।
`AGENTS.md`, top-level README, pubspec, iOS settings এবং অন্য approved module
patch target নয়। Backup path apply output-এ দেখাবে।

শুধু preflight:

```bash
python3 ~/Downloads/DocDiary_Leave_Record_Patch/apply_leave_record_patch.py . --check
```

Restore (apply output থেকে exact backup path নেবেন):

```bash
python3 ~/Downloads/DocDiary_Leave_Record_Patch/apply_leave_record_patch.py . --restore /path/to/backup.zip
```

Restore করার পরে করা নতুন edit overwrite হয় না; আগে conflict জানায়।

Simulator-এ সব branch, None, তিনটি filter, month Cancel/OK, STATUS summary,
empty data, Retry/Cancel এবং Back দেখবেন। Screenshot native-এর সঙ্গে মিলিয়ে
দেখবেন। বাস্তব iPhone ও live API-তে যাচাই এবং macOS/Xcode build এখানে হয়নি।
Preview থাকলে সেটি Flutter widget render এবং synthetic data; live data নয়।

Automated verification-এর ফল: `docs/verification/leave_record_validation_2026-10-24.md`।
