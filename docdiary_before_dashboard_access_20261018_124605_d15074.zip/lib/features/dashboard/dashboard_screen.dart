import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/failure.dart';
import '../../core/native_dates.dart';
import '../auth/auth_controller.dart';
import '../auth/auth_models.dart';
import '../auth/profile_repository.dart';
import 'admin_chart_repository.dart';
import 'native_admin_overview.dart';
import 'dashboard_repository.dart';
import 'meeting_countdown.dart';
import 'native_dashboard_layout.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.auth,
    required this.repository,
  });
  final AuthController auth;
  final DashboardRepository repository;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with WidgetsBindingObserver {
  late AccountProfile _profile;
  late final AuthSession _session;
  DashboardSummary? _summary;
  Uint8List? _picture;
  SummaryPeriod _period = SummaryPeriod.today;
  String? _error;
  bool _loading = false;
  bool _noticeOpen = false;
  int _request = 0;
  int _pictureRequest = 0;
  int _overviewRevision = 0;
  MeetingTimeline? _meeting;
  MeetingSnapshot? _countdown;
  Timer? _meetingTicker;
  Timer? _expiryRefresh;
  DateTime? _expiryRefreshAt;
  bool _foreground = true;
  bool _expiryDue = false;
  bool _resumePending = false;
  bool _meetingRefreshing = false;

  bool get _current =>
      mounted &&
      widget.auth.stage == AuthStage.authenticated &&
      widget.auth.session == _session;

  @override
  void initState() {
    super.initState();
    _profile = widget.auth.profile!;
    _session = widget.auth.session!;
    final state = WidgetsBinding.instance.lifecycleState;
    _foreground = state == null || state == AppLifecycleState.resumed;
    WidgetsBinding.instance.addObserver(this);
    widget.auth.addListener(_authChanged);
    // AuthController already checked this account before opening the dashboard.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(_load(revalidate: false, refreshPicture: true));
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _foreground = false;
      _resumePending = false;
      _stopMeetingClock();
      return;
    }
    if (_foreground) {
      return;
    }
    _foreground = true;
    if (_current) {
      _resumePending = true;
      if (!_loading) {
        _reloadOnResume();
      }
    }
  }

  void _authChanged() {
    if (!_current) {
      _resumePending = false;
      _stopMeetingClock();
    }
  }

  void _cancelExpiryRefresh() {
    _expiryRefresh?.cancel();
    _expiryRefresh = null;
    _expiryRefreshAt = null;
    _expiryDue = false;
  }

  void _stopMeetingClock() {
    _meetingTicker?.cancel();
    _meetingTicker = null;
    _cancelExpiryRefresh();
  }

  void _adoptMeeting(DashboardSummary result) {
    final previous = _meeting;
    _meeting =
        _profile.isDoctor
            ? MeetingTimeline.update(
              lastTime: result.lastTime,
              nextTime: result.nextTime,
              observedAt: widget.repository.now(),
              previous: previous,
            )
            : null;
    _startMeetingClock();
  }

  void _startMeetingClock() {
    _meetingTicker?.cancel();
    _meetingTicker = null;
    _countdown = _meeting?.at(widget.repository.now());
    // Once time is up, finish the native Today refresh even if a tab request
    // returns first. Its week/month counts cannot be relabelled as Today.
    if (_expiryRefreshAt != null || _expiryDue) {
      _meetingRefreshing = true;
      return;
    }
    _meetingRefreshing = false;
    if (!_current || !_foreground || _error != null) {
      return;
    }
    final meeting = _meeting;
    if (meeting == null) {
      _cancelExpiryRefresh();
      return;
    }
    if (_countdown!.expired) {
      _meetingRefreshing = true;
      _scheduleExpiryRefresh();
      return;
    }
    _cancelExpiryRefresh();
    _meetingTicker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!_current || !_foreground) {
        _stopMeetingClock();
        return;
      }
      setState(() {
        _countdown = meeting.at(widget.repository.now());
        if (_countdown!.expired) {
          _meetingTicker?.cancel();
          _meetingTicker = null;
          // Android hides the dashboard/navigation and shows its main spinner
          // during the 3-second delay and the subsequent schedule request.
          _meetingRefreshing = true;
          _scheduleExpiryRefresh();
        }
      });
    });
  }

  void _scheduleExpiryRefresh() {
    if (_expiryDue || _expiryRefresh?.isActive == true) {
      return;
    }
    _expiryRefreshAt ??= widget.repository.now().add(
      const Duration(seconds: 3),
    );
    final delay = _expiryRefreshAt!.difference(widget.repository.now());
    _expiryRefresh = Timer(delay.isNegative ? Duration.zero : delay, () {
      _expiryRefresh = null;
      if (!_current || !_foreground) {
        return;
      }
      if (_loading) {
        // A tab/pull request already owns the connection. Drain one queued
        // Today refresh after it finishes, without overlapping requests.
        _expiryDue = true;
        return;
      }
      _reloadAfterMeeting();
    });
  }

  void _reloadAfterMeeting() {
    _cancelExpiryRefresh();
    setState(() => _period = SummaryPeriod.today);
    unawaited(_load(revalidate: false, refreshPicture: true));
  }

  void _reloadOnResume() {
    _resumePending = false;
    _stopMeetingClock();
    setState(() {
      _period = SummaryPeriod.today;
      _countdown = _meeting?.at(widget.repository.now());
      _meetingRefreshing = _profile.isDoctor && _summary != null;
    });
    // Revalidate without inserting a second login log or changing login flags.
    unawaited(_load(refreshPicture: true));
  }

  Future<void> _load({
    bool revalidate = true,
    bool refreshPicture = false,
  }) async {
    if (!_current || !_foreground || _loading) {
      return;
    }
    final session = widget.auth.session;
    if (session == null) {
      return;
    }
    final request = ++_request;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final profile =
          revalidate
              ? await widget.auth.profiles.open(session, recordLogin: false)
              : _profile;
      if (!_current || request != _request || widget.auth.session != session) {
        return;
      }
      final result = await widget.repository.load(session, profile, _period);
      if (!_current || request != _request || widget.auth.session != session) {
        return;
      }
      setState(() {
        _profile = profile;
        _summary = result;
        if (refreshPicture) {
          ++_overviewRevision;
        }
        _adoptMeeting(result);
      });
      if (refreshPicture) {
        unawaited(_loadPicture(session, profile));
      }
    } catch (failure) {
      if (!_current || request != _request || widget.auth.session != session) {
        return;
      }
      if (failure is AppFailure && failure.kind == FailureKind.denied) {
        await widget.auth.logout(message: failure.message);
        return;
      }
      setState(
        () =>
            _error =
                failure is AppFailure
                    ? failure.message
                    : 'Dashboard data could not be loaded. Please try again.',
      );
    } finally {
      if (_current && request == _request) {
        setState(() {
          _loading = false;
          if (_error != null) {
            // A failed read requires an explicit retry/resume. Never hammer
            // the backend or turn a connection failure into "no meeting".
            _stopMeetingClock();
            _meetingRefreshing = false;
          }
        });
        if (_foreground && _resumePending) {
          _reloadOnResume();
        } else if (_foreground && _expiryDue) {
          _reloadAfterMeeting();
        }
      }
    }
  }

  Future<void> _loadPicture(AuthSession session, AccountProfile profile) async {
    final request = ++_pictureRequest;
    Uint8List? picture;
    try {
      picture = await widget.repository.loadPicture(session, profile);
    } catch (_) {
      // A failed optional picture request uses the native role-specific image.
    }
    if (_current &&
        request == _pictureRequest &&
        widget.auth.session == session) {
      setState(() => _picture = picture);
    }
  }

  Future<void> _refresh() => _load(refreshPicture: true);

  Future<void> _selectPeriod(SummaryPeriod period) async {
    if (_loading || period == _period) {
      return;
    }
    setState(() => _period = period);
    await _load();
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Log Out!'),
            content: const Text('Do you want to log out?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Yes'),
              ),
            ],
          ),
    );
    if (confirmed == true && mounted) {
      await widget.auth.logout();
    }
  }

  Future<void> _openDestination(DashboardDestination destination) async {
    if (_noticeOpen) {
      return;
    }
    _noticeOpen = true;
    final label = switch (destination) {
      DashboardDestination.profile => 'Profile',
      DashboardDestination.appointment => 'Appointment',
      DashboardDestination.leave => 'Block Time',
      DashboardDestination.patients => 'Patient',
      DashboardDestination.payment => 'Payment',
      DashboardDestination.management =>
        nativeDashboardMenu(
          _profile,
        ).firstWhere((item) => item.destination == destination).label,
      DashboardDestination.unitAppointment => 'Unit Appointment',
      DashboardDestination.allAppointment => 'All Appointment',
      DashboardDestination.reports => 'Report Manager',
      DashboardDestination.changePhoto => 'Profile picture',
    };
    try {
      await showDialog<void>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: Text(label),
              content: const Text(
                'This screen is not available in this development build.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close'),
                ),
              ],
            ),
      );
    } finally {
      _noticeOpen = false;
    }
  }

  @override
  void dispose() {
    ++_request;
    ++_pictureRequest;
    _stopMeetingClock();
    widget.auth.removeListener(_authChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => NativeDashboardLayout(
    profile: _profile,
    summary: _summary,
    picture: _picture,
    period: _period,
    now: _summary?.asOf ?? widget.repository.now(),
    countdown: _countdown,
    meetingRefreshing: _meetingRefreshing,
    adminOverview:
        _profile.isDoctor
            ? null
            : NativeAdminOverview(
              key: ValueKey(
                'overview:${_session.center.baseUri}:${_session.account.key}',
              ),
              auth: widget.auth,
              profile: _profile,
              repository: AdminChartRepository(
                widget.repository.transport,
                now: widget.repository.now,
              ),
              refreshRevision: _overviewRevision,
              sdp:
                  MediaQuery.sizeOf(context).shortestSide < 300
                      ? 1
                      : (MediaQuery.sizeOf(context).shortestSide / 30).floor() *
                          30 /
                          300,
            ),
    loading: _loading,
    error: _error,
    showSwitch: widget.auth.canSwitch,
    onSwitch: widget.auth.beginSwitch,
    onLogout: _logout,
    onPeriod: _selectPeriod,
    onRefresh: _refresh,
    onDestination: _openDestination,
  );
}
