enum FailureKind { network, server, invalidData, denied, storage }

class AppFailure implements Exception {
  const AppFailure(this.message, {this.kind = FailureKind.server});
  final String message;
  final FailureKind kind;

  @override
  String toString() => message;
}
